# Changelog

## [1.13] - 2026-11-11
### Añadido
- **Acceso local por tipo de usuario**: administradores con correo y contraseña; empleados no administradores con PIN personal. Se mantiene la matriz de permisos por rol y el bloqueo temporal tras intentos fallidos.
- **Modo oscuro** persistente, accesible desde la barra superior y desde Personalización. Mantiene los temas corporativos existentes.
- Selector demostrativo de modalidad comercial: suite completa o solo POS (sin pasarela de suscripción ni cobro integrado).
- **Nueva pantalla de inicio de LK POS** con accesos operativos, estados de caja y avisos. La interfaz POS usa una distribución propia y conserva la paleta elegida para LK ONE.
- **POS contextual**: nomenclatura adaptada para barberías/peluquerías (sillas y profesionales) y spas (cabinas y especialistas). Se amplía la recomendación del POS a comercios minoristas.
- **Nuevas actividades**: abarrotes/tienda de barrio, tienda de conveniencia, carnicería, papelería y floristería.
- Campo de cliente renombrado a **Celular (opcional)**.
- Migración a esquema 6 compatible, con campos locales de correo y hash de contraseña para usuarios.

### Ajustado
- El acceso de administrador requiere correo y contraseña de al menos 8 caracteres al activar autenticación local. El personal utiliza PIN.
- Se aclara en la interfaz y documentación que este acceso local no sustituye autenticación de servidor ni proporciona seguridad para despliegue público.

### Límites explícitos de esta entrega
- Sin backend obligatorio: abrir `index.html` y guardar en el navegador. No hay sincronización entre dispositivos ni ejecución de automatizaciones con el navegador cerrado.
- WhatsApp automático, tasas oficiales en vivo, facturación fiscal electrónica, reloj de asistencia fiable en segundo plano, pagos en línea y seguridad multiempresa requieren integraciones/infraestructura y no se simulan.
- El POS contextual 1.13 incorpora estructura de interfaz y términos por actividad; los flujos especializados completos de cocina, barbería, tienda y spa continúan siendo trabajo de siguientes iteraciones.

## [1.12] - 2026-11-10
### Añadido
- LK POS para restaurantes, gastronomía, mesas, pedidos, cocina, caja, inventario y reportes.
- 51 actividades con módulos recomendados, configuración internacional, roles y PIN, calendario y cola de WhatsApp sin proveedor.
- Esquema de datos 5 y mejoras de persistencia local/servidor opcional.
