# LK ONE — Versión 1.13 (beta local, sin backend obligatorio)

Plataforma de gestión configurable para negocios de distintos sectores y países. La arquitectura combina un núcleo empresarial común con módulos opcionales y plantillas por actividad.

## Abrir la beta

1. Descomprime el ZIP.
2. Abre `index.html` en Chrome, Edge o Safari.
3. Los datos se guardan en el navegador (`localStorage` + IndexedDB para adjuntos).
4. Exporta respaldos JSON con regularidad desde Configuración.

No es necesario ejecutar `npm start` ni instalar dependencias para probar la modalidad local. `server.js` se conserva como herramienta heredada/opcional del proyecto 1.12, pero esta entrega no depende de él.

## Probar el código

```bash
npm test
```

Requiere Node 18 o superior. Las pruebas de navegador se omiten si Playwright/Chromium no está instalado.

## Novedades de 1.13

- Inicio de administrador por correo/contraseña y acceso de empleado por PIN (local y demostrativo).
- Permisos y vistas por rol.
- Modo oscuro y personalización persistente.
- Pantalla inicial propia del POS con accesos operativos y paleta compartida con LK ONE.
- Contextualización inicial del POS para barberías, peluquerías y spa.
- POS recomendado también para comercio minorista y nuevas actividades: abarrotes, conveniencia, carnicería, papelería y floristería.
- Campo de celular opcional en clientes.

## Límites importantes

Esta versión funciona sin backend, pero el almacenamiento es local a ese navegador y dispositivo. El PIN/contraseña local no es un sistema de seguridad empresarial ni debe usarse para datos sensibles o despliegue público. No hay sincronización multi-dispositivo.

WhatsApp automático, tasas oficiales en tiempo real, facturación electrónica fiscal, pagos en línea, automatizaciones en segundo plano y autenticación centralizada requieren servicios externos y/o backend. No se presentan como funciones activas.

## Estructura

- `index.html`, `styles.css`, `app.js`: interfaz y persistencia local.
- `catalog.js`: actividades, países, monedas, roles y permisos.
- `core.js`: validaciones, operaciones, inventario y migraciones.
- `pos-core.js`, `pos-ui.js`: motor e interfaz del POS.
- `automation-core.js`: planificación local de avisos y cola manual (sin envío automático).
- `tests/`: pruebas automatizadas.
